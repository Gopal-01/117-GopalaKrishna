import React from 'react';
import './App.css';
import Navbar from './components/Navbar';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/about';
// import Slideshow from './pages/slideshow';
import SignUp from './pages/signup';
import login from './pages/login';
import balance from './pages/balance';
import paybill from './pages/paybill';
import withdraw from './pages/withdraw';
import deposit from './pages/deposit';
import another from './pages/another'
function App() {
return (
	<Router>
	<Navbar />
 
	<Switch>
		<Route path='/' exact component={Home} />
		<Route path='/about' component={About} />
		<Route path='/balance' component={balance} />
		<Route path='/login' component={login} />
		<Route path='/Signup' component={SignUp} />
		<Route path='/paybill' component={paybill} />
		<Route path='/withdraw' component={withdraw} />
		<Route path='/deposit' component={deposit} />
		<Route path='/another' component={another} />
	</Switch>
	
	</Router>
);
}

export default App;
