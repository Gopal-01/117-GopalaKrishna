import React from 'react';
import {
Nav,
NavLink,
Bars,
NavMenu,
NavBtn,
NavBtnLink,
} from './NavbarElements';

const Navbar = () => {
return (
	<>
	<Nav>
	

		<NavMenu>
		<NavLink to='/about' activeStyle>
			About
			</NavLink>
			<NavLink to='/balance' activeStyle>
			Balance Amount
			</NavLink>
			<NavLink to='/withdraw' activeStyle>
			WithDraw Amount
			</NavLink>
			<NavLink to='/deposit' activeStyle>
			Deposit Amount
			</NavLink>
			<NavLink to='/paybill' activeStyle>
			Pay Bills
			</NavLink>
			<NavLink to='/another' activeStyle>
			Transfer 
			</NavLink>
			
	
		
		<NavBtnLink to='/login'>Login</NavBtnLink>
		</NavMenu>
		<NavBtn>
		<NavBtnLink to='/signup'>Add Account</NavBtnLink>
		</NavBtn>
	</Nav>
	</>
);
};

export default Navbar;
