import React from 'react';
import Slideshow from './slideshow';
import Card from "react-bootstrap/Card";

const Home = () => {
return (
	
	<div>
	<h1>welcome to bank
	.</h1>
    <Slideshow/>
	  <div>
	  <Card style={{ width: "22rem" }}>
        <Card.Body>
          <Card.Title style={{ color: "green" }}>Register for Online Bills Payment</Card.Title>
          
          <Card.Text>
            You can pay the Bills
          </Card.Text>
          <Card.Link href="#">Register</Card.Link>
        </Card.Body>
      </Card></div>
	  <div>
	  <Card style={{ width: "22rem" }}>
        <Card.Body>
          <Card.Title style={{ color: "green" }}>Register for Online banking</Card.Title>
          
          <Card.Text>
            You can transform money from your account to another account
          </Card.Text>
          <Card.Link href="#">Register</Card.Link>
        </Card.Body>
      </Card>
            </div>
			
	</div>
  
);
};

export default Home;
