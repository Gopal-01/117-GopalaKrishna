import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";


export default function another() {


  function handleSubmit(event) {
    event.preventDefault();
  }

  return (
    <div className="balance">
      
      <Form className="Account1">
      <h1 className="user">Transfer to Another Account</h1>
      
      <Form >

      <Form.Label>Account number1</Form.Label><br></br>
      <Form.Label>Balance Amount</Form.Label><Form.Label></Form.Label><br></br>
          <Form.Label>Account number</Form.Label>
          <Form.Label>Enter the amount</Form.Label>
          <input
            type="text"
            // value={}
            // onChange={}
         />
          <Form.Label></Form.Label><br></br>
          
        <Button block size="lg" type="submit" >
          Transfet to account2
        </Button>
      </Form>
      </Form>


      <Form className="Account2">
      <h1 className="user">Transfer to Another Account</h1>
      
      <Form >

      <Form.Label>Account number2</Form.Label><br></br>
      <Form.Label>Balance Amount</Form.Label><Form.Label></Form.Label><br></br>
          <Form.Label>Account number</Form.Label>
          <Form.Label>Enter the amount</Form.Label>
          <input
            type="text"
            // value={}
            // onChange={}
         />
          <Form.Label></Form.Label><br></br>
          
        <Button block size="lg" type="submit" >
          Transfet to account1
        </Button>
      </Form>
      </Form>
	  
    </div>
  );
}