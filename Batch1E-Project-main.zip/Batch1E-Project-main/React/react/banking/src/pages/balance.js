import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";


export default function Balance() {


  function handleSubmit(event) {
    event.preventDefault();
  }

  return (
    <div className="balance">
      
      <Form className="Account 1">
      <h1 className="user">Account 1</h1>
      <Form >
          <Form.Label>Account number</Form.Label>
          
          <Form.Label></Form.Label>
          
        <Button block size="lg" type="submit" >
          Check Balance
        </Button>
      </Form>
      </Form>
      
	  <Form className="Account 2">
      <h1 className="user">Account 2</h1>
      <Form >
          <Form.Label>Account number</Form.Label>
          
          <Form.Label></Form.Label>
          
        <Button block size="lg" type="submit" >
          Check Balance
        </Button>
      </Form>
      </Form>
    </div>
  );
}