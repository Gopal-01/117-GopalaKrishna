import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import 'bootstrap/dist/css/bootstrap.css';
import Dropdown from 'react-bootstrap/Dropdown';

export default function deposit() {


  function handleSubmit(event) {
    event.preventDefault();
  }

  return (
    <div className="balance">
      
      <Form className="Account">
      <h1 className="user">Deposit</h1>
      
      <Form >
       <div style={{ display: 'block', 
                  width: 900, 
                  padding: 50 }}>
      <Dropdown>
        <Dropdown.Toggle variant="success">
          Select bank Account
        </Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item href="#">
           Account 1
          </Dropdown.Item>
          <Dropdown.Item href="#">
            Account 2
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
    </div>
      <Form.Label>Balance Amount</Form.Label><Form.Label></Form.Label><br></br>
          <Form.Label>Account number</Form.Label><br></br>
          <Form.Label>Enter the amount</Form.Label>
          <input
            type="number"
            
         />
          <Form.Label></Form.Label><br></br>
          
        <Button block size="lg" type="submit" >
          deposit amount
        </Button>
      </Form>
      </Form>
      
	  
    </div>
  );
}