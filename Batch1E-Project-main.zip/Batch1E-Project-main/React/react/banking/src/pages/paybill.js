import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";


export default function paybill() {


  function handleSubmit(event) {
    event.preventDefault();
  }
  

  return (
    <div className="paybill">
      
      <Form className="Account">
      <h1 className="user">Pay Bills</h1>
      
      <Form >
      <Form.Label>mobile Recharge</Form.Label><br></br>
          
          <Form.Label>mobile number</Form.Label>
          <select value="">
  <option value="Airtel">Airtel</option>
  <option value="jio">Jio</option>
  <option value="VI">VI</option>
</select>

          <input
            type="text"
            // value={}
            // onChange={}
         />
          <Form.Label></Form.Label><br></br>
          
        <Button block size="lg" type="submit" >
          Recharge
        </Button>&nbsp;&nbsp;
          <Button block size="lg" type="submit" >
          Register for buller
        </Button>
      </Form>
      </Form>
      
	  
    </div>
  );
}