import React, { Component } from 'react'
import axios from 'axios';
  
import DatePicker from 'react-datepicker';  
   
import "react-datepicker/dist/react-datepicker.css";  
import 'bootstrap/dist/css/bootstrap.min.css';  
  
class Signup extends Component{

    constructor(props){
        super(props)
        this.state={
            firstName:'',
            lastName:'',
            emailId:'',
            address:'',
            startDate: new Date()  
        }

        this.changeFirstNameHandler=this.changeFirstNameHandler.bind(this);
        this.changeLastNameHandler=this.changeLastNameHandler.bind(this);
        this.changeEmailIdHandler=this.changeEmailIdHandler.bind(this);
        this.changeAddressHandler=this.changeAddressHandler.bind(this);
        this.saveStudent=this.saveStudent.bind(this);
          this.handleChange = this.handleChange.bind(this);  
    this.onFormSubmit = this.onFormSubmit.bind(this);  
    }

    changeFirstNameHandler=(event)=>{
        this.setState({firstName: event.target.value});
    }

    changeLastNameHandler=(event)=>{
        this.setState({lastName: event.target.value});
    }

    changeEmailIdHandler=(event)=>{
        this.setState({emailId: event.target.value});
    }

    changeAddressHandler=(event)=>{
        this.setState({address: event.target.value});
    }

    saveStudent=(e)=>{
        e.preventDefault();
        let student={firstName: this.state.firstName,lastName: this.state.lastName,emailId: this.state.emailId, address: this.state.address};
        console.log('Student=>'+JSON.stringify(student));
    }
      handleChange(date) {  
    this.setState({  
      startDate: date  
    })  
  }  
  
  onFormSubmit(e) {  
    e.preventDefault();  
    console.log(this.state.startDate)  
  }  
   


    cancel(){
        this.props.history.push();
    }
    state = {
 
        // Initially, no file is selected
        selectedFile: null
      };
      
      // On file select (from the pop up)
      onFileChange = event => {
      
        // Update the state
        this.setState({ selectedFile: event.target.files[0] });
      
      };
      
      // On file upload (click the upload button)
      onFileUpload = () => {
      
        // Create an object of formData
        const formData = new FormData();
      
        // Update the formData object
        formData.append(
          "myFile",
          this.state.selectedFile,
          this.state.selectedFile.name
        );
      
        // Details of the uploaded file
        console.log(this.state.selectedFile);
      
        // Request made to the backend api
        // Send formData object
        axios.post("api/uploadfile", formData);
      };
      
      // File content to be displayed after
      // file upload is complete
      fileData = () => {
      
        if (this.state.selectedFile) {
           
          return (
            <div>
              <h2>File Details:</h2>
               
  <p>File Name: {this.state.selectedFile.name}</p>
   
               
  <p>File Type: {this.state.selectedFile.type}</p>
   
               
  <p>
                Last Modified:{" "}
                {this.state.selectedFile.lastModifiedDate.toDateString()}
              </p>
   
            </div>
          );
        } else {
          return (
            <div>
              <br />
              <h4>Choose before Pressing the Upload button</h4>
            </div>
          );
        }
      };
    render(){
        return(
            <div>

            <div className="container">
                <div className="row">
                    <br></br>
                    <h1 className="text-center">Add User Account</h1>
                    <br></br>
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                        <div className="card-body">
                            <form>
                            <div className="form-group">
                            <label>Title:</label>
                            <select value="">
                            <option value="Mr">Mr</option>
                            <option value="Ms">Ms</option>
                            </select>
                            </div>
                            
                                <div className="form-group">
                                    <label>First Name:</label>
                                    <input placeholder="First Name" name="firstName" className="form-control"
                                    value={this.state.firstName} onChange={this.changeFirstNameHandler}/>
                                </div>
                                 <div className="form-group">  
                                 <label>Date of burth:</label>
          <DatePicker  
              selected={ this.state.startDate }  
              onChange={ this.handleChange }  
              name="startDate"  
              dateFormat="MM/dd/yyyy"  
          />  
          <button className="btn btn-primary">Show Date</button>  
        </div>  
                                <div className="form-group">
                                    <label>Mobile Number:</label>
                                    <input placeholder="Enter mobile number"  className="form-control"
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Email:</label>
                                    <input placeholder="Email" name="emailId" className="form-control"
                                    value={this.state.emailId} onChange={this.changeEmailIdHandler}/>
                                </div>
                                <div className="form-group">
                                    <label>Address:</label>
                                    <input placeholder="Address" name="address" className="form-control"
                                    value={this.state.address} onChange={this.changeAddressHandler}/>
                                </div>
                                <br></br>
                                <br></br>
                                <div>
          
            
            <div>
            <label>Uplode the aadar</label> <input type="text" placeholder="Enter aadar number"></input>
                <input type="file" onChange={this.onFileChange} />
                <button onClick={this.onFileUpload}>
                  Upload!
                </button>
            </div>
            <div>
            <label>Uplode the PAN</label> <input type="text" placeholder="Enter pan number"></input>
                <input type="file" onChange={this.onFileChange} />
                <button onClick={this.onFileUpload}>
                  Upload!
                </button>
            </div>
          {this.fileData()}
        </div>
                                <button className="btn btn-success" onClick={this.saveStudent}>Submit</button>
                                <button className="btn btn-danger" onClick={this.cancel.bind} style={{marginLeft:"10px"}}>Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        )
    }
}

export default Signup