
let melead1 = [1,2,3]
let melead = []
const inputEl = document.getElementById("input-el")
let  inputbtn = document.getElementById("input=btn")
const ulel = document.getElementById("ul-el")

inputbtn.addEventListener("click", function(){
    melead.push(inputEl.value)
    inputEl.value= ""
    renderlead()
    
})
function renderlead()
{
let listitem = " "
for(let i=0;i<melead.length;i++)
{
listitem += "<li><a target='_blank' href='" + melead[i] + "'>" + melead[i] + "</a>"
       
}
ulel.innerHTML = listitem
}














// let divbox = document.getElementById("box")

// divbox .addEventListener("click", function(){
//     console.log("box ix clicked")
// })

// for(let i =0;i<melead1.length;i++)
// {
//     console.log(melead1[i])
// }


// let name = "gopal"

// // const mail = "hi " +name+ " happy to seee you!!"

// //convert to template string or literals

// const mail1 = `hi
//  ${name} welcome to 
//  the world!!
//  ! `
// console.log(mail1)